Tugas relasi data Orders dan Shippers

Controllers : app/Controllers/Order.php

Models : app/Models/Modelorder.php

Views : app/Views/vieworder.php
